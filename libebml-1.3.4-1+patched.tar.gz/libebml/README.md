# libebml
a C++ libary to parse EBML files

Specifications may be rendered at http://matroska-org.github.io/libebml/
